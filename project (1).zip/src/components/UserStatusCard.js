import React from "react";
import ProgressBar from "./ProgressBar";

const UserStatusCard = ({ userProgress }) => {
  const totalXp = 1000;
  const progress = (userProgress.currentXp / totalXp) * 100;

  return (
    <div className="bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-700">
      <h3 className="text-xl font-bold mb-4 text-white">Tu Progreso</h3>
      
      <div className="mb-6">
        <div className="flex justify-between mb-1">
          <span className="text-sm font-medium text-gray-300">Nivel 1</span>
          <span className="text-sm font-medium text-green-400">
            {userProgress.currentXp}/{totalXp} XP
          </span>
        </div>
        <ProgressBar percentage={progress} />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gray-700 rounded-lg p-3 text-center">
          <p className="text-sm text-gray-400">Lecciones</p>
          <p className="text-xl font-bold">
            {userProgress.completedLessons.length}
          </p>
        </div>
        
        <div className="bg-gray-700 rounded-lg p-3 text-center">
          <p className="text-sm text-gray-400">Racha</p>
          <p className="text-xl font-bold">
            {userProgress.streakDays} días
          </p>
        </div>
      </div>
    </div>
  );
};

export default UserStatusCard;