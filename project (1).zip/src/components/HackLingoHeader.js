import React from "react";

const HackLingoHeader = () => {
  return (
    <header className="bg-black text-green-400 py-4 px-6 shadow-md">
      <div className="flex justify-between items-center max-w-6xl mx-auto">
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
            HL
          </div>
          <h1 className="text-xl font-bold">HackLingo</h1>
        </div>
        <nav className="hidden md:flex space-x-6">
          <a href="#lessons" className="hover:text-green-300 transition-colors">
            Lecciones
          </a>
          <a href="#status" className="hover:text-green-300 transition-colors">
            Progreso
          </a>
          <a href="#profile" className="hover:text-green-300 transition-colors">
            Perfil
          </a>
        </nav>
        <div className="w-10 h-10 bg-gray-800 rounded-full"></div>
      </div>
    </header>
  );
};

export default HackLingoHeader;