const lessons = [
  {
    id: 1,
    title: "Introducción al Hacking Ético",
    description: "Aprende los fundamentos sin romper la ley",
    icon: "👨‍💻",
    difficulty: "Fácil",
    xp: 100,
  },
  {
    id: 2,
    title: "SQL Injection Básico",
    description: "Cómo hackear bases de datos (legalmente)",
    icon: "💉",
    difficulty: "Intermedio",
    xp: 200,
  },
  {
    id: 3,
    title: "WiFi Hacking",
    description: "Descifra contraseñas (con permiso)",
    icon: "📡",
    difficulty: "Avanzado",
    xp: 300,
  },
  {
    id: 4,
    title: "Phishing Awareness",
    description: "Cómo no caer en los trucos más comunes",
    icon: "🎣",
    difficulty: "Fácil",
    xp: 150,
  },
  {
    id: 5,
    title: "OSINT Básico",
    description: "Técnicas de investigación en fuentes abiertas",
    icon: "🔍",
    difficulty: "Intermedio",
    xp: 250,
  },
];

export default lessons;