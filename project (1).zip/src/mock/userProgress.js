const userProgress = {
  completedLessons: [1],
  currentXp: 100,
  streakDays: 3,
  lastLogin: "2023-06-15",
};

export default userProgress;