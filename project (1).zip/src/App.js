import React, { useState } from "react";
import HackLingoHeader from "./components/HackLingoHeader";
import LessonsGrid from "./components/LessonsGrid";
import UserStatusCard from "./components/UserStatusCard";
import userProgress from "./mock/userProgress";

const App = () => {
  const [currentUserProgress, setCurrentUserProgress] = useState(userProgress);
  const [activeView, setActiveView] = useState("lessons");

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <HackLingoHeader />
      
      <main className="max-w-6xl mx-auto py-8 px-6">
        {activeView === "lessons" ? (
          <>
            <UserStatusCard userProgress={currentUserProgress} />
            <LessonsGrid />
          </>
        ) : (
          <div className="text-center py-20">
            <h2 className="text-2xl font-bold mb-4">Próximamente más funciones!</h2>
            <p className="text-gray-400">Estamos hackeando el sistema para traerte más contenido.</p>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;

// DONE